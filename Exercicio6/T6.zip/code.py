import pandas as pd
import numpy as np
import scipy as scipy
from nltk import word_tokenize          
from nltk.stem import WordNetLemmatizer
from sklearn import preprocessing
from sklearn import model_selection
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_files
from sklearn.decomposition import PCA
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import GradientBoostingClassifier

class LemmaTokenizer(object):
  def __init__(self):
    self.wnl = WordNetLemmatizer()
  def __call__(self, doc):
    try:
      doc = doc.split(" ")
      text = " ".join(CountVectorizer().fit(doc).get_feature_names())
      return [self.wnl.lemmatize(t) for t in word_tokenize(text)]
    except:
      return []

files = load_files("filesk")
categories = files.target
LT = LemmaTokenizer()

vectorizer = CountVectorizer(lowercase=True,strip_accents="ascii",stop_words="english",min_df=2, binary=True, tokenizer=LT)
transformer = TfidfTransformer(smooth_idf=False)

BAG_DATA = np.array(vectorizer.fit_transform(files.data).toarray())
TERM_FREQUENCY = np.array(transformer.fit_transform(BAG_DATA).toarray())

SPLIT = train_test_split(BAG_DATA, categories, test_size=0.2, random_state=np.random.randint(13))
BAG_X_TRAIN, BAG_X_TEST, BAG_Y_TRAIN, BAG_Y_TEST = SPLIT

SPLIT = train_test_split(TERM_FREQUENCY, categories, test_size=0.2, random_state=np.random.randint(13))
TERM_X_TRAIN, TERM_X_TEST, TERM_Y_TRAIN, TERM_Y_TEST = SPLIT

gnb = GaussianNB()
gnb.fit(BAG_X_TRAIN, BAG_Y_TRAIN)
print("Gaussian Naive Bayes accuracy with binary matrix: {0}%".format(100 * accuracy_score(BAG_Y_TEST, gnb.predict(BAG_X_TEST))))

mnb = MultinomialNB()
mnb.fit(BAG_X_TRAIN, BAG_Y_TRAIN)
print("Multinomial Naive Bayes accuracy with binary matrix: {0}%".format(100 * accuracy_score(BAG_Y_TEST, mnb.predict(BAG_X_TEST))))

bnb= BernoulliNB()
bnb.fit(BAG_X_TRAIN, BAG_Y_TRAIN)
print("Bernoulli Naive Bayes accuracy with binary matrix: {0}%".format(100 * accuracy_score(BAG_Y_TEST, bnb.predict(BAG_X_TEST))))

lr = LogisticRegression(C=10000)
lr.fit(BAG_X_TRAIN, BAG_Y_TRAIN)
print("Logistic Regression accuracy with binary matrix: {0}%".format(100 * accuracy_score(BAG_Y_TEST, lr.predict(BAG_X_TEST))))

lr = LogisticRegression(C=10000)
lr.fit(TERM_X_TRAIN, TERM_Y_TRAIN)
print("Logistic Regression accuracy with term frequency: {0}%".format(100 * accuracy_score(TERM_Y_TEST, lr.predict(TERM_X_TEST))))

pca = PCA(n_components=0.99,copy=False)
pca.fit(TERM_X_TRAIN)
PCA_TERM_X_TRAIN = np.array(pca.transform(TERM_X_TRAIN))
PCA_TERM_X_TEST = np.array(pca.transform(TERM_X_TEST))

svm = SVC()
svm.fit(PCA_TERM_X_TRAIN, TERM_Y_TRAIN)
print("SVC accuracy with term frequency PCA: {0}%".format(100 * accuracy_score(TERM_Y_TEST, svm.predict(PCA_TERM_X_TEST))))

gbm = GradientBoostingClassifier()
gbm.fit(PCA_TERM_X_TRAIN, TERM_Y_TRAIN)
print("Gradient Boosting accuracy with term frequency PCA: {0}%".format(100 * accuracy_score(TERM_Y_TEST, gbm.predict(PCA_TERM_X_TEST))))




